For Docs on how to use packwiz once installed, please visit the docs/ folder.
For instructions on how to install packwiz, visit [their website](https://packwiz.infra.link/installation/)
